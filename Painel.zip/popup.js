function myFunction() {
    window.open("http://google.com.br", "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=1, left=1, width=1, height=1");     
}